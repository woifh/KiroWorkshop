"""
Events API Backend

A FastAPI-based serverless API for managing events with DynamoDB.
"""
